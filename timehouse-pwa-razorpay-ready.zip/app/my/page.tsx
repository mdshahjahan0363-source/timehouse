"use client"

import { useState } from "react"
import Link from "next/link"
import {
  User,
  Package,
  MapPin,
  LifeBuoy,
  LogOut,
  ChevronRight,
  Trash2,
  X,
} from "lucide-react"
import { useStore } from "@/lib/store"
import { BottomNav } from "@/components/bottom-nav"
import { Spinner } from "@/components/state-views"
import { Field, TextInput } from "@/components/ui/field"
import { useToast } from "@/lib/toast"

type Panel = "orders" | "address" | "help" | null

export default function MyPage() {
  const toast = useToast()
  const { ready, profile, setProfile, orders, addresses, removeAddress } =
    useStore()
  const [panel, setPanel] = useState<Panel>(null)
  const [form, setForm] = useState({ name: "", email: "", phone: "" })

  if (!ready) {
    return (
      <main className="mx-auto min-h-dvh max-w-md bg-background">
        <Spinner label="Loading profile..." />
      </main>
    )
  }

  if (!profile) {
    return (
      <main className="mx-auto min-h-dvh max-w-md bg-background pb-24">
        <header className="border-b border-border px-4 py-4">
          <h1 className="font-serif text-xl text-foreground">My Account</h1>
        </header>
        <div className="px-4 pt-10">
          <div className="mx-auto flex size-16 items-center justify-center rounded-full bg-secondary text-primary">
            <User className="size-8" />
          </div>
          <h2 className="mt-4 text-center font-serif text-lg text-foreground">
            Sign in to continue
          </h2>
          <p className="mt-1 text-center text-sm text-muted-foreground">
            Access your profile, orders and saved addresses.
          </p>
          <form
            className="mt-6 space-y-3"
            onSubmit={(e) => {
              e.preventDefault()
              if (!form.name.trim() || !form.email.trim()) {
                toast("Enter your name and email", "error")
                return
              }
              setProfile({
                name: form.name.trim(),
                email: form.email.trim(),
                phone: form.phone.trim(),
              })
              toast("Signed in successfully", "success")
            }}
          >
            <Field label="Full Name" htmlFor="name">
              <TextInput
                id="name"
                value={form.name}
                onChange={(e) => setForm({ ...form, name: e.target.value })}
                placeholder="Your name"
              />
            </Field>
            <Field label="Email" htmlFor="email">
              <TextInput
                id="email"
                type="email"
                value={form.email}
                onChange={(e) => setForm({ ...form, email: e.target.value })}
                placeholder="you@example.com"
              />
            </Field>
            <Field label="Mobile (optional)" htmlFor="phone">
              <TextInput
                id="phone"
                inputMode="numeric"
                value={form.phone}
                onChange={(e) =>
                  setForm({
                    ...form,
                    phone: e.target.value.replace(/\D/g, "").slice(0, 10),
                  })
                }
                placeholder="10-digit mobile"
              />
            </Field>
            <button
              type="submit"
              className="w-full rounded-xl bg-primary py-3 text-sm font-semibold text-primary-foreground"
            >
              Sign In
            </button>
          </form>
        </div>
        <BottomNav />
      </main>
    )
  }

  const initials = profile.name
    .split(" ")
    .map((n) => n[0])
    .slice(0, 2)
    .join("")
    .toUpperCase()

  const menu = [
    { id: "orders" as const, label: "My Orders", icon: Package, note: `${orders.length} orders` },
    { id: "address" as const, label: "Saved Address", icon: MapPin, note: `${addresses.length} saved` },
    { id: "help" as const, label: "Help & Support", icon: LifeBuoy, note: "" },
  ]

  return (
    <main className="mx-auto min-h-dvh max-w-md bg-background pb-24">
      <header className="border-b border-border px-4 py-4">
        <h1 className="font-serif text-xl text-foreground">My Account</h1>
      </header>

      <section className="px-4 pt-5">
        <div className="flex items-center gap-4 rounded-2xl border border-border bg-card p-4">
          <div className="flex size-14 items-center justify-center rounded-full bg-primary font-serif text-lg font-semibold text-primary-foreground">
            {initials || <User className="size-6" />}
          </div>
          <div className="min-w-0 flex-1">
            <h2 className="truncate font-medium text-foreground">
              {profile.name}
            </h2>
            <p className="truncate text-sm text-muted-foreground">
              {profile.email}
            </p>
            {profile.phone && (
              <p className="text-xs text-muted-foreground">+91 {profile.phone}</p>
            )}
          </div>
        </div>
      </section>

      <section className="mt-4 px-4">
        <div className="overflow-hidden rounded-2xl border border-border bg-card">
          {menu.map((item, i) => {
            const Icon = item.icon
            return (
              <button
                key={item.id}
                onClick={() => setPanel(item.id)}
                className={`flex w-full items-center gap-3 px-4 py-3.5 text-left transition-colors hover:bg-secondary/50 ${
                  i > 0 ? "border-t border-border" : ""
                }`}
              >
                <Icon className="size-5 text-primary" />
                <span className="flex-1 text-sm text-foreground">
                  {item.label}
                </span>
                {item.note && (
                  <span className="text-xs text-muted-foreground">
                    {item.note}
                  </span>
                )}
                <ChevronRight className="size-4 text-muted-foreground" />
              </button>
            )
          })}
        </div>

        <button
          onClick={() => {
            setProfile(null)
            toast("Logged out", "info")
          }}
          className="mt-4 flex w-full items-center justify-center gap-2 rounded-2xl border border-destructive/40 py-3.5 text-sm font-semibold text-destructive transition-colors hover:bg-destructive/10"
        >
          <LogOut className="size-4" />
          Logout
        </button>
      </section>

      {panel === "orders" && (
        <Sheet title="My Orders" onClose={() => setPanel(null)}>
          {orders.length === 0 ? (
            <p className="py-8 text-center text-sm text-muted-foreground">
              You have no orders yet.
            </p>
          ) : (
            <div className="space-y-2">
              {orders.map((o) => (
                <Link
                  key={o.id}
                  href="/history"
                  className="flex items-center justify-between rounded-xl border border-border bg-card px-3 py-3"
                >
                  <div>
                    <p className="font-mono text-xs text-foreground">#{o.id}</p>
                    <p className="text-xs capitalize text-muted-foreground">
                      {o.orderStatus} · {o.paymentStatus}
                    </p>
                  </div>
                  <ChevronRight className="size-4 text-muted-foreground" />
                </Link>
              ))}
            </div>
          )}
        </Sheet>
      )}

      {panel === "address" && (
        <Sheet title="Saved Address" onClose={() => setPanel(null)}>
          {addresses.length === 0 ? (
            <p className="py-8 text-center text-sm text-muted-foreground">
              No saved addresses yet. They&apos;re saved automatically at
              checkout.
            </p>
          ) : (
            <div className="space-y-2">
              {addresses.map((a, i) => (
                <div
                  key={i}
                  className="flex items-start justify-between gap-3 rounded-xl border border-border bg-card p-3"
                >
                  <div className="text-sm">
                    <p className="font-medium text-foreground">{a.fullName}</p>
                    <p className="text-muted-foreground">
                      {a.address}, {a.city}, {a.state} - {a.pincode}
                    </p>
                    <p className="text-xs text-muted-foreground">
                      +91 {a.mobile}
                    </p>
                  </div>
                  <button
                    onClick={() => removeAddress(i)}
                    className="text-muted-foreground hover:text-destructive"
                    aria-label="Remove address"
                  >
                    <Trash2 className="size-4" />
                  </button>
                </div>
              ))}
            </div>
          )}
        </Sheet>
      )}

      {panel === "help" && (
        <Sheet title="Help & Support" onClose={() => setPanel(null)}>
          <div className="space-y-3 text-sm">
            <div className="rounded-xl border border-border bg-card p-4">
              <p className="font-medium text-foreground">Customer Care</p>
              <p className="mt-1 text-muted-foreground">
                Available Mon–Sat, 10 AM – 7 PM IST
              </p>
              <p className="mt-2 text-primary">support@aurelia-watches.example</p>
              <p className="text-primary">+91 1800 000 000</p>
            </div>
            <div className="rounded-xl border border-border bg-card p-4 text-muted-foreground">
              <p className="font-medium text-foreground">Returns &amp; Warranty</p>
              <p className="mt-1">
                All timepieces include a 2-year international warranty and a
                7-day return window.
              </p>
            </div>
          </div>
        </Sheet>
      )}

      <BottomNav />
    </main>
  )
}

function Sheet({
  title,
  onClose,
  children,
}: {
  title: string
  onClose: () => void
  children: React.ReactNode
}) {
  return (
    <div className="fixed inset-0 z-[80] flex items-end justify-center bg-background/70 backdrop-blur-sm">
      <div className="max-h-[80vh] w-full max-w-md overflow-y-auto rounded-t-3xl border-t border-border bg-popover p-4 animate-in slide-in-from-bottom">
        <div className="mb-4 flex items-center justify-between">
          <h3 className="font-serif text-lg text-foreground">{title}</h3>
          <button
            onClick={onClose}
            className="flex size-8 items-center justify-center rounded-full border border-border text-muted-foreground"
            aria-label="Close"
          >
            <X className="size-4" />
          </button>
        </div>
        {children}
      </div>
    </div>
  )
}
