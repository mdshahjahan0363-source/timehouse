"use client"

import Link from "next/link"
import Image from "next/image"
import { useRouter } from "next/navigation"
import { Minus, Plus, Trash2, ShoppingBag } from "lucide-react"
import { useStore } from "@/lib/store"
import { discountedPrice } from "@/lib/types"
import { formatINR } from "@/lib/format"
import { BottomNav } from "@/components/bottom-nav"
import { EmptyState, Spinner } from "@/components/state-views"

export default function CartPage() {
  const router = useRouter()
  const { cart, products, ready, setQuantity, removeFromCart, cartTotal } =
    useStore()

  const lines = cart
    .map((c) => {
      const product = products.find((p) => p.id === c.productId)
      return product ? { product, quantity: c.quantity } : null
    })
    .filter((x): x is { product: (typeof products)[number]; quantity: number } => x !== null)

  return (
    <main className="mx-auto min-h-dvh max-w-md bg-background pb-24">
      <header className="sticky top-0 z-40 border-b border-border bg-background/90 px-4 py-4 backdrop-blur">
        <h1 className="font-serif text-xl text-foreground">Shopping Cart</h1>
        <p className="text-xs text-muted-foreground">
          {lines.length} {lines.length === 1 ? "item" : "items"}
        </p>
      </header>

      {!ready ? (
        <Spinner label="Loading cart..." />
      ) : lines.length === 0 ? (
        <EmptyState
          icon={<ShoppingBag className="size-7" />}
          title="Your cart is empty"
          description="Browse our collection and add your favourite timepieces."
          action={
            <Link
              href="/"
              className="mt-2 rounded-full bg-primary px-5 py-2 text-sm font-semibold text-primary-foreground"
            >
              Start shopping
            </Link>
          }
        />
      ) : (
        <>
          <ul className="space-y-3 px-4 pt-4">
            {lines.map(({ product, quantity }) => {
              const price = discountedPrice(product)
              const maxed = quantity >= product.stock
              return (
                <li
                  key={product.id}
                  className="flex gap-3 rounded-2xl border border-border bg-card p-3"
                >
                  <Link
                    href={`/product/${product.id}`}
                    className="relative size-20 shrink-0 overflow-hidden rounded-xl bg-secondary/40"
                  >
                    <Image
                      src={product.image || "/placeholder.svg"}
                      alt={product.name}
                      fill
                      sizes="80px"
                      className="object-cover"
                    />
                  </Link>
                  <div className="flex flex-1 flex-col">
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <h3 className="line-clamp-1 text-sm font-medium text-foreground">
                          {product.name}
                        </h3>
                        <p className="text-sm font-semibold text-foreground">
                          {formatINR(price)}
                        </p>
                      </div>
                      <button
                        onClick={() => removeFromCart(product.id)}
                        className="text-muted-foreground transition-colors hover:text-destructive"
                        aria-label={`Remove ${product.name}`}
                      >
                        <Trash2 className="size-4" />
                      </button>
                    </div>
                    <div className="mt-auto flex items-center gap-2 pt-2">
                      <div className="flex items-center rounded-lg border border-border">
                        <button
                          onClick={() =>
                            setQuantity(product.id, quantity - 1)
                          }
                          className="flex size-8 items-center justify-center text-foreground disabled:opacity-40"
                          aria-label="Decrease quantity"
                        >
                          <Minus className="size-3.5" />
                        </button>
                        <span className="w-8 text-center text-sm font-medium tabular-nums">
                          {quantity}
                        </span>
                        <button
                          onClick={() =>
                            setQuantity(product.id, quantity + 1)
                          }
                          disabled={maxed}
                          className="flex size-8 items-center justify-center text-foreground disabled:opacity-40"
                          aria-label="Increase quantity"
                        >
                          <Plus className="size-3.5" />
                        </button>
                      </div>
                      {maxed && (
                        <span className="text-[10px] text-warning">
                          Max stock
                        </span>
                      )}
                    </div>
                  </div>
                </li>
              )
            })}
          </ul>

          <div className="mt-6 space-y-3 px-4">
            <div className="rounded-2xl border border-border bg-card p-4">
              <div className="flex items-center justify-between text-sm text-muted-foreground">
                <span>Subtotal</span>
                <span>{formatINR(cartTotal)}</span>
              </div>
              <div className="flex items-center justify-between text-sm text-muted-foreground">
                <span>Delivery</span>
                <span className="text-success">Free</span>
              </div>
              <div className="mt-3 flex items-center justify-between border-t border-border pt-3">
                <span className="font-medium text-foreground">Total</span>
                <span className="font-serif text-xl text-foreground">
                  {formatINR(cartTotal)}
                </span>
              </div>
            </div>
            <button
              onClick={() => router.push("/checkout")}
              className="w-full rounded-xl bg-primary py-3.5 text-sm font-semibold text-primary-foreground transition-opacity hover:opacity-90"
            >
              Proceed to Checkout
            </button>
          </div>
        </>
      )}

      <BottomNav />
    </main>
  )
}
