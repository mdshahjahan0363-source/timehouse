import { type NextRequest, NextResponse } from "next/server"
import { ADMIN_COOKIE, isValidSessionToken } from "@/lib/admin-auth"

export async function GET(req: NextRequest) {
  const token = req.cookies.get(ADMIN_COOKIE)?.value
  return NextResponse.json({ authenticated: isValidSessionToken(token) })
}

export async function DELETE() {
  const res = NextResponse.json({ ok: true })
  res.cookies.set(ADMIN_COOKIE, "", { path: "/", maxAge: 0 })
  return res
}
