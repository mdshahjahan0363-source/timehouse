import { type NextRequest, NextResponse } from "next/server"
import crypto from "crypto"

export async function POST(req: NextRequest) {
  const keySecret = process.env.RAZORPAY_KEY_SECRET
  if (!keySecret) {
    return NextResponse.json(
      { verified: false, error: "Razorpay is not configured." },
      { status: 503 },
    )
  }

  let body: {
    razorpay_order_id?: string
    razorpay_payment_id?: string
    razorpay_signature?: string
  }
  try {
    body = await req.json()
  } catch {
    return NextResponse.json(
      { verified: false, error: "Invalid request body" },
      { status: 400 },
    )
  }

  const { razorpay_order_id, razorpay_payment_id, razorpay_signature } = body

  if (!razorpay_order_id || !razorpay_payment_id || !razorpay_signature) {
    return NextResponse.json(
      { verified: false, error: "Missing payment fields" },
      { status: 400 },
    )
  }

  // Verify the signature server-side. The order is only trusted when the
  // HMAC of "order_id|payment_id" signed with the secret matches.
  const expected = crypto
    .createHmac("sha256", keySecret)
    .update(`${razorpay_order_id}|${razorpay_payment_id}`)
    .digest("hex")

  const verified =
    expected.length === razorpay_signature.length &&
    crypto.timingSafeEqual(
      Buffer.from(expected),
      Buffer.from(razorpay_signature),
    )

  if (!verified) {
    return NextResponse.json({ verified: false }, { status: 400 })
  }

  return NextResponse.json({ verified: true, paymentId: razorpay_payment_id })
}
