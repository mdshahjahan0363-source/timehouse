"use client"

import { useEffect, useState } from "react"
import Link from "next/link"
import { useRouter } from "next/navigation"
import {
  ChevronLeft,
  CreditCard,
  Smartphone,
  Building2,
  Loader2,
  ShoppingBag,
} from "lucide-react"
import { useStore } from "@/lib/store"
import { discountedPrice } from "@/lib/types"
import type {
  Address,
  Order,
  OrderLine,
  PaymentMethod,
  PaymentStatus,
} from "@/lib/types"
import { formatINR } from "@/lib/format"
import { Field, TextInput } from "@/components/ui/field"
import { EmptyState, Spinner } from "@/components/state-views"
import { PaymentResult, type ResultState } from "@/components/payment-result"
import { useToast } from "@/lib/toast"
import { cn } from "@/lib/utils"

declare global {
  interface Window {
    Razorpay?: new (options: Record<string, unknown>) => {
      open: () => void
      on: (event: string, handler: (res: unknown) => void) => void
    }
  }
}

const PAYMENT_OPTIONS: {
  id: PaymentMethod
  label: string
  note: string
  icon: typeof CreditCard
}[] = [
  { id: "online", label: "Online Payment", note: "Card / Wallet", icon: CreditCard },
  { id: "upi", label: "UPI", note: "GPay, PhonePe, Paytm", icon: Smartphone },
  { id: "netbanking", label: "Net Banking", note: "All major banks", icon: Building2 },
]

const empty: Address = {
  fullName: "",
  mobile: "",
  address: "",
  city: "",
  state: "",
  pincode: "",
}

function loadRazorpayScript(): Promise<boolean> {
  return new Promise((resolve) => {
    if (window.Razorpay) return resolve(true)
    const script = document.createElement("script")
    script.src = "https://checkout.razorpay.com/v1/checkout.js"
    script.onload = () => resolve(true)
    script.onerror = () => resolve(false)
    document.body.appendChild(script)
  })
}

export default function CheckoutPage() {
  const router = useRouter()
  const toast = useToast()
  const {
    cart,
    products,
    ready,
    cartTotal,
    profile,
    addresses,
    saveAddress,
    addOrder,
    clearCart,
  } = useStore()

  const [address, setAddress] = useState<Address>(empty)
  const [method, setMethod] = useState<PaymentMethod>("online")
  const [errors, setErrors] = useState<Partial<Record<keyof Address, string>>>({})
  const [processing, setProcessing] = useState(false)
  const [result, setResult] = useState<ResultState>(null)

  useEffect(() => {
    if (addresses[0]) {
      setAddress(addresses[0])
    } else if (profile) {
      setAddress((a) => ({ ...a, fullName: profile.name, mobile: profile.phone }))
    }
  }, [addresses, profile])

  const lines: OrderLine[] = cart
    .map((c) => {
      const p = products.find((x) => x.id === c.productId)
      if (!p) return null
      return {
        productId: p.id,
        name: p.name,
        image: p.image,
        price: discountedPrice(p),
        quantity: c.quantity,
      }
    })
    .filter((x): x is OrderLine => x !== null)

  function update(field: keyof Address, value: string) {
    setAddress((a) => ({ ...a, [field]: value }))
    setErrors((e) => ({ ...e, [field]: undefined }))
  }

  function validate(): boolean {
    const next: Partial<Record<keyof Address, string>> = {}
    if (!address.fullName.trim()) next.fullName = "Required"
    if (!/^[0-9]{10}$/.test(address.mobile.trim()))
      next.mobile = "Enter a valid 10-digit mobile"
    if (!address.address.trim()) next.address = "Required"
    if (!address.city.trim()) next.city = "Required"
    if (!address.state.trim()) next.state = "Required"
    if (!/^[0-9]{6}$/.test(address.pincode.trim()))
      next.pincode = "Enter a valid 6-digit PIN"
    setErrors(next)
    return Object.keys(next).length === 0
  }

  function finalizeOrder(
    status: PaymentStatus,
    razorpay?: { orderId?: string; paymentId?: string },
  ) {
    const order: Order = {
      id: `AUR${Date.now().toString().slice(-8)}`,
      createdAt: Date.now(),
      items: lines,
      amount: cartTotal,
      address,
      paymentMethod: method,
      paymentStatus: status,
      orderStatus: status === "paid" ? "Confirmed" : "Pending",
      razorpayOrderId: razorpay?.orderId,
      razorpayPaymentId: razorpay?.paymentId,
    }
    addOrder(order)
    if (status === "paid") clearCart()
    return order
  }

  async function handlePay() {
    if (!validate()) {
      toast("Please fix the highlighted fields", "error")
      return
    }
    saveAddress(address)
    setProcessing(true)

    try {
      const orderRes = await fetch("/api/razorpay/order", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ amount: cartTotal }),
      })

      if (!orderRes.ok) {
        const data = await orderRes.json().catch(() => ({}))
        toast(data.error ?? "Could not start payment", "error")
        setProcessing(false)
        return
      }

      const { orderId, amount, currency, keyId } = await orderRes.json()

      const ok = await loadRazorpayScript()
      if (!ok || !window.Razorpay) {
        toast("Failed to load payment gateway", "error")
        setProcessing(false)
        return
      }

      const rzp = new window.Razorpay({
        key: keyId,
        amount,
        currency,
        order_id: orderId,
        name: "AURELIA",
        description: "Luxury Timepieces",
        prefill: {
          name: address.fullName,
          contact: address.mobile,
          email: profile?.email ?? "",
        },
        theme: { color: "#c9a227" },
        method:
          method === "upi"
            ? { upi: true }
            : method === "netbanking"
              ? { netbanking: true }
              : undefined,
        handler: async (response: unknown) => {
          const r = response as {
            razorpay_order_id: string
            razorpay_payment_id: string
            razorpay_signature: string
          }
          try {
            const verifyRes = await fetch("/api/razorpay/verify", {
              method: "POST",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify(r),
            })
            const verifyData = await verifyRes.json()
            if (verifyRes.ok && verifyData.verified) {
              const order = finalizeOrder("paid", {
                orderId: r.razorpay_order_id,
                paymentId: r.razorpay_payment_id,
              })
              setResult({ status: "paid", orderId: order.id, amount: order.amount })
            } else {
              const order = finalizeOrder("pending", {
                orderId: r.razorpay_order_id,
                paymentId: r.razorpay_payment_id,
              })
              setResult({
                status: "pending",
                orderId: order.id,
                amount: order.amount,
              })
            }
          } catch {
            const order = finalizeOrder("pending", {
              orderId: r.razorpay_order_id,
            })
            setResult({
              status: "pending",
              orderId: order.id,
              amount: order.amount,
            })
          } finally {
            setProcessing(false)
          }
        },
      })

      rzp.on("payment.failed", () => {
        setResult({ status: "failed", orderId: "", amount: cartTotal })
        setProcessing(false)
      })

      // If the user dismisses the checkout without paying, stop the spinner.
      rzp.on("modal.closed" as string, () => setProcessing(false))

      rzp.open()
    } catch (err) {
      console.log("[v0] Checkout error:", err)
      toast("Something went wrong. Please try again.", "error")
      setProcessing(false)
    }
  }

  if (!ready) {
    return (
      <main className="mx-auto min-h-dvh max-w-md bg-background">
        <Spinner label="Loading checkout..." />
      </main>
    )
  }

  if (lines.length === 0 && !result) {
    return (
      <main className="mx-auto min-h-dvh max-w-md bg-background">
        <EmptyState
          icon={<ShoppingBag className="size-7" />}
          title="Nothing to checkout"
          description="Your cart is empty."
          action={
            <Link
              href="/"
              className="mt-2 rounded-full bg-primary px-5 py-2 text-sm font-semibold text-primary-foreground"
            >
              Browse watches
            </Link>
          }
        />
      </main>
    )
  }

  return (
    <main className="mx-auto min-h-dvh max-w-md bg-background pb-32">
      <header className="sticky top-0 z-40 flex items-center gap-3 border-b border-border bg-background/90 px-4 py-3 backdrop-blur">
        <button
          onClick={() => router.back()}
          className="flex size-9 items-center justify-center rounded-full border border-border text-foreground"
          aria-label="Go back"
        >
          <ChevronLeft className="size-5" />
        </button>
        <h1 className="font-serif text-lg text-foreground">Checkout</h1>
      </header>

      <div className="space-y-6 px-4 pt-5">
        <section>
          <h2 className="mb-3 text-sm font-semibold uppercase tracking-wide text-muted-foreground">
            Delivery Details
          </h2>
          <div className="space-y-3">
            <Field label="Full Name" htmlFor="fullName" error={errors.fullName}>
              <TextInput
                id="fullName"
                value={address.fullName}
                onChange={(e) => update("fullName", e.target.value)}
                placeholder="John Doe"
                autoComplete="name"
              />
            </Field>
            <Field label="Mobile Number" htmlFor="mobile" error={errors.mobile}>
              <TextInput
                id="mobile"
                inputMode="numeric"
                value={address.mobile}
                onChange={(e) =>
                  update("mobile", e.target.value.replace(/\D/g, "").slice(0, 10))
                }
                placeholder="10-digit mobile number"
                autoComplete="tel"
              />
            </Field>
            <Field label="Full Address" htmlFor="address" error={errors.address}>
              <TextInput
                id="address"
                value={address.address}
                onChange={(e) => update("address", e.target.value)}
                placeholder="House no, street, area"
                autoComplete="street-address"
              />
            </Field>
            <div className="grid grid-cols-2 gap-3">
              <Field label="City" htmlFor="city" error={errors.city}>
                <TextInput
                  id="city"
                  value={address.city}
                  onChange={(e) => update("city", e.target.value)}
                  placeholder="City"
                />
              </Field>
              <Field label="State" htmlFor="state" error={errors.state}>
                <TextInput
                  id="state"
                  value={address.state}
                  onChange={(e) => update("state", e.target.value)}
                  placeholder="State"
                />
              </Field>
            </div>
            <Field label="PIN Code" htmlFor="pincode" error={errors.pincode}>
              <TextInput
                id="pincode"
                inputMode="numeric"
                value={address.pincode}
                onChange={(e) =>
                  update("pincode", e.target.value.replace(/\D/g, "").slice(0, 6))
                }
                placeholder="6-digit PIN code"
                autoComplete="postal-code"
              />
            </Field>
          </div>
        </section>

        <section>
          <h2 className="mb-3 text-sm font-semibold uppercase tracking-wide text-muted-foreground">
            Payment Method
          </h2>
          <div className="space-y-2">
            {PAYMENT_OPTIONS.map((opt) => {
              const Icon = opt.icon
              const active = method === opt.id
              return (
                <button
                  key={opt.id}
                  onClick={() => setMethod(opt.id)}
                  className={cn(
                    "flex w-full items-center gap-3 rounded-2xl border p-3.5 text-left transition-colors",
                    active
                      ? "border-primary bg-primary/10"
                      : "border-border bg-card",
                  )}
                >
                  <div
                    className={cn(
                      "flex size-10 items-center justify-center rounded-xl",
                      active
                        ? "bg-primary text-primary-foreground"
                        : "bg-secondary text-muted-foreground",
                    )}
                  >
                    <Icon className="size-5" />
                  </div>
                  <div className="flex-1">
                    <p className="text-sm font-medium text-foreground">
                      {opt.label}
                    </p>
                    <p className="text-xs text-muted-foreground">{opt.note}</p>
                  </div>
                  <span
                    className={cn(
                      "flex size-5 items-center justify-center rounded-full border",
                      active ? "border-primary" : "border-border",
                    )}
                  >
                    {active && <span className="size-2.5 rounded-full bg-primary" />}
                  </span>
                </button>
              )
            })}
          </div>
        </section>

        <section>
          <h2 className="mb-3 text-sm font-semibold uppercase tracking-wide text-muted-foreground">
            Order Summary
          </h2>
          <div className="space-y-3 rounded-2xl border border-border bg-card p-4">
            {lines.map((l) => (
              <div
                key={l.productId}
                className="flex items-center justify-between text-sm"
              >
                <span className="line-clamp-1 text-muted-foreground">
                  {l.name} × {l.quantity}
                </span>
                <span className="shrink-0 font-medium text-foreground">
                  {formatINR(l.price * l.quantity)}
                </span>
              </div>
            ))}
            <div className="flex items-center justify-between border-t border-border pt-3">
              <span className="font-medium text-foreground">Total</span>
              <span className="font-serif text-xl text-foreground">
                {formatINR(cartTotal)}
              </span>
            </div>
          </div>
        </section>
      </div>

      <div className="fixed inset-x-0 bottom-0 z-40 mx-auto max-w-md border-t border-border bg-popover/95 p-3 backdrop-blur">
        <button
          onClick={handlePay}
          disabled={processing}
          className="flex w-full items-center justify-center gap-2 rounded-xl bg-primary py-3.5 text-sm font-semibold text-primary-foreground transition-opacity hover:opacity-90 disabled:opacity-60 pb-[env(safe-area-inset-bottom)]"
        >
          {processing ? (
            <>
              <Loader2 className="size-4 animate-spin" />
              Processing...
            </>
          ) : (
            <>Pay Now · {formatINR(cartTotal)}</>
          )}
        </button>
      </div>

      <PaymentResult
        result={result}
        onRetry={() => {
          setResult(null)
          handlePay()
        }}
        onClose={() => {
          setResult(null)
          if (result?.status === "paid") router.push("/history")
        }}
      />
    </main>
  )
}
