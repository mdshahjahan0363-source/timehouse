"use client"

import Link from "next/link"
import { useState } from "react"
import { Search, Watch, ShieldCheck, Truck, X } from "lucide-react"
import { useStore } from "@/lib/store"
import { ProductCard } from "@/components/product-card"
import { BottomNav } from "@/components/bottom-nav"
import { EmptyState, ProductSkeleton } from "@/components/state-views"
import { TextInput } from "@/components/ui/field"

export default function HomePage() {
  const { products, ready } = useStore()
  const [query, setQuery] = useState("")

  const filtered = products.filter((p) =>
    `${p.name} ${p.brand ?? ""}`.toLowerCase().includes(query.toLowerCase()),
  )

  return (
    <main className="mx-auto min-h-dvh max-w-md bg-background pb-24">
      <header className="sticky top-0 z-40 border-b border-border bg-background/90 backdrop-blur">
        <div className="flex items-center justify-between px-4 pb-3 pt-4">
          <div>
            <p className="text-[10px] font-semibold uppercase tracking-[0.25em] text-primary/80">
              Aurelia
            </p>
            <h1 className="font-serif text-xl leading-tight text-foreground">
              Luxury Timepieces
            </h1>
          </div>
          <Link
            href="/admin"
            className="rounded-full border border-border px-3 py-1.5 text-xs font-medium text-muted-foreground transition-colors hover:text-foreground"
          >
            Admin
          </Link>
        </div>
        <div className="relative px-4 pb-3">
          <Search className="pointer-events-none absolute left-7 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
          <TextInput
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search watches"
            className="pl-9"
            aria-label="Search watches"
          />
          {query && (
            <button
              onClick={() => setQuery("")}
              className="absolute right-7 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
              aria-label="Clear search"
            >
              <X className="size-4" />
            </button>
          )}
        </div>
      </header>

      {!query && (
        <section className="px-4 pt-4">
          <div className="relative overflow-hidden rounded-3xl border border-border bg-gradient-to-br from-secondary via-card to-background p-5">
            <div className="relative z-10 max-w-[70%]">
              <p className="text-[10px] font-semibold uppercase tracking-[0.2em] text-primary">
                New Collection
              </p>
              <h2 className="mt-1 font-serif text-2xl leading-tight text-foreground">
                Timeless craftsmanship on your wrist
              </h2>
              <p className="mt-2 text-xs text-muted-foreground">
                Hand-picked luxury watches, delivered with care.
              </p>
            </div>
            <Watch className="absolute -right-4 -top-2 size-32 text-primary/15" />
          </div>
          <div className="mt-3 grid grid-cols-2 gap-3">
            <Feature icon={ShieldCheck} title="Authentic" note="100% genuine" />
            <Feature icon={Truck} title="Fast Delivery" note="Across India" />
          </div>
        </section>
      )}

      <section className="px-4 pt-6">
        <div className="mb-3 flex items-baseline justify-between">
          <h2 className="font-serif text-lg text-foreground">
            {query ? "Results" : "All Watches"}
          </h2>
          <span className="text-xs text-muted-foreground">
            {filtered.length} items
          </span>
        </div>

        {!ready ? (
          <div className="grid grid-cols-2 gap-3">
            {Array.from({ length: 4 }).map((_, i) => (
              <ProductSkeleton key={i} />
            ))}
          </div>
        ) : filtered.length === 0 ? (
          <EmptyState
            icon={<Watch className="size-7" />}
            title="No watches found"
            description={
              query
                ? "Try a different search term."
                : "Products will appear here once added."
            }
          />
        ) : (
          <div className="grid grid-cols-2 gap-3">
            {filtered.map((p) => (
              <ProductCard key={p.id} product={p} />
            ))}
          </div>
        )}
      </section>

      <BottomNav />
    </main>
  )
}

function Feature({
  icon: Icon,
  title,
  note,
}: {
  icon: typeof ShieldCheck
  title: string
  note: string
}) {
  return (
    <div className="flex items-center gap-2.5 rounded-2xl border border-border bg-card px-3 py-2.5">
      <Icon className="size-5 text-primary" />
      <div>
        <p className="text-xs font-medium text-foreground">{title}</p>
        <p className="text-[10px] text-muted-foreground">{note}</p>
      </div>
    </div>
  )
}
