"use client"

import Link from "next/link"
import Image from "next/image"
import { Clock, Package } from "lucide-react"
import { useStore } from "@/lib/store"
import { formatINR, formatDate } from "@/lib/format"
import { BottomNav } from "@/components/bottom-nav"
import { EmptyState, Spinner } from "@/components/state-views"
import { PaymentBadge, OrderStatusBadge } from "@/components/status-badge"

export default function HistoryPage() {
  const { orders, ready } = useStore()

  return (
    <main className="mx-auto min-h-dvh max-w-md bg-background pb-24">
      <header className="sticky top-0 z-40 border-b border-border bg-background/90 px-4 py-4 backdrop-blur">
        <h1 className="font-serif text-xl text-foreground">Order History</h1>
        <p className="text-xs text-muted-foreground">
          {orders.length} {orders.length === 1 ? "order" : "orders"}
        </p>
      </header>

      {!ready ? (
        <Spinner label="Loading orders..." />
      ) : orders.length === 0 ? (
        <EmptyState
          icon={<Clock className="size-7" />}
          title="No orders yet"
          description="Your completed orders will appear here."
          action={
            <Link
              href="/"
              className="mt-2 rounded-full bg-primary px-5 py-2 text-sm font-semibold text-primary-foreground"
            >
              Start shopping
            </Link>
          }
        />
      ) : (
        <ul className="space-y-3 px-4 pt-4">
          {orders.map((order) => (
            <li
              key={order.id}
              className="overflow-hidden rounded-2xl border border-border bg-card"
            >
              <div className="flex items-center justify-between gap-2 border-b border-border px-4 py-3">
                <div>
                  <p className="font-mono text-xs text-muted-foreground">
                    #{order.id}
                  </p>
                  <p className="text-[11px] text-muted-foreground">
                    {formatDate(order.createdAt)}
                  </p>
                </div>
                <div className="flex flex-col items-end gap-1">
                  <PaymentBadge status={order.paymentStatus} />
                  <OrderStatusBadge status={order.orderStatus} />
                </div>
              </div>

              <div className="space-y-2.5 px-4 py-3">
                {order.items.map((item) => (
                  <div key={item.productId} className="flex items-center gap-3">
                    <div className="relative size-12 shrink-0 overflow-hidden rounded-lg bg-secondary/40">
                      <Image
                        src={item.image || "/placeholder.svg"}
                        alt={item.name}
                        fill
                        sizes="48px"
                        className="object-cover"
                      />
                    </div>
                    <div className="flex-1">
                      <p className="line-clamp-1 text-sm text-foreground">
                        {item.name}
                      </p>
                      <p className="text-xs text-muted-foreground">
                        {formatINR(item.price)} × {item.quantity}
                      </p>
                    </div>
                  </div>
                ))}
              </div>

              <div className="flex items-center justify-between border-t border-border px-4 py-3">
                <span className="flex items-center gap-1.5 text-xs text-muted-foreground">
                  <Package className="size-3.5" />
                  {order.items.reduce((n, i) => n + i.quantity, 0)} items
                </span>
                <span className="font-semibold text-foreground">
                  {formatINR(order.amount)}
                </span>
              </div>
            </li>
          ))}
        </ul>
      )}

      <BottomNav />
    </main>
  )
}
