"use client"

import { use, useState } from "react"
import Link from "next/link"
import Image from "next/image"
import { useRouter } from "next/navigation"
import { ChevronLeft, ShoppingBag, Zap, Watch } from "lucide-react"
import { useStore } from "@/lib/store"
import { discountedPrice } from "@/lib/types"
import { formatINR } from "@/lib/format"
import { StockBadge } from "@/components/status-badge"
import { EmptyState, Spinner } from "@/components/state-views"
import { useToast } from "@/lib/toast"

export default function ProductPage({
  params,
}: {
  params: Promise<{ id: string }>
}) {
  const { id } = use(params)
  const router = useRouter()
  const toast = useToast()
  const { getProduct, addToCart, ready } = useStore()
  const [active, setActive] = useState(0)

  if (!ready) {
    return (
      <main className="mx-auto min-h-dvh max-w-md bg-background">
        <Spinner label="Loading watch..." />
      </main>
    )
  }

  const product = getProduct(id)

  if (!product) {
    return (
      <main className="mx-auto min-h-dvh max-w-md bg-background">
        <EmptyState
          icon={<Watch className="size-7" />}
          title="Watch not found"
          description="This product may have been removed."
          action={
            <Link
              href="/"
              className="mt-2 rounded-full bg-primary px-5 py-2 text-sm font-semibold text-primary-foreground"
            >
              Back to shop
            </Link>
          }
        />
      </main>
    )
  }

  const gallery = [product.image, ...(product.gallery ?? [])]
  const price = discountedPrice(product)
  const soldOut = product.stock <= 0

  const handleAddToCart = () => {
    addToCart(product.id)
    toast("Added to cart", "success")
  }

  const handleBuyNow = () => {
    addToCart(product.id)
    router.push("/checkout")
  }

  return (
    <main className="mx-auto min-h-dvh max-w-md bg-background pb-28">
      <header className="sticky top-0 z-40 flex items-center gap-3 border-b border-border bg-background/90 px-4 py-3 backdrop-blur">
        <button
          onClick={() => router.back()}
          className="flex size-9 items-center justify-center rounded-full border border-border text-foreground"
          aria-label="Go back"
        >
          <ChevronLeft className="size-5" />
        </button>
        <h1 className="line-clamp-1 font-serif text-lg text-foreground">
          {product.name}
        </h1>
      </header>

      <div className="relative aspect-square bg-secondary/30">
        <Image
          src={gallery[active] || "/placeholder.svg"}
          alt={product.name}
          fill
          sizes="(max-width: 480px) 100vw, 448px"
          className="object-cover"
          priority
        />
        {product.discount > 0 && (
          <span className="absolute left-4 top-4 rounded-full bg-primary px-3 py-1 text-xs font-bold text-primary-foreground">
            -{product.discount}% OFF
          </span>
        )}
      </div>

      {gallery.length > 1 && (
        <div className="flex gap-2 px-4 pt-3">
          {gallery.map((g, i) => (
            <button
              key={i}
              onClick={() => setActive(i)}
              className={`relative size-16 overflow-hidden rounded-xl border ${
                active === i ? "border-primary" : "border-border"
              }`}
              aria-label={`View image ${i + 1}`}
            >
              <Image
                src={g || "/placeholder.svg"}
                alt=""
                fill
                sizes="64px"
                className="object-cover"
              />
            </button>
          ))}
        </div>
      )}

      <div className="space-y-4 px-4 pt-4">
        <div>
          {product.brand && (
            <p className="text-[11px] font-semibold uppercase tracking-[0.2em] text-primary/80">
              {product.brand}
            </p>
          )}
          <h2 className="mt-1 font-serif text-2xl text-foreground">
            {product.name}
          </h2>
        </div>

        <div className="flex items-center gap-3">
          <span className="text-2xl font-semibold text-foreground">
            {formatINR(price)}
          </span>
          {product.discount > 0 && (
            <span className="text-base text-muted-foreground line-through">
              {formatINR(product.price)}
            </span>
          )}
        </div>

        <StockBadge stock={product.stock} />

        <div className="rounded-2xl border border-border bg-card p-4">
          <h3 className="mb-1.5 text-sm font-semibold text-foreground">
            Description
          </h3>
          <p className="text-sm leading-relaxed text-muted-foreground">
            {product.description}
          </p>
        </div>
      </div>

      <div className="fixed inset-x-0 bottom-0 z-40 mx-auto max-w-md border-t border-border bg-popover/95 p-3 backdrop-blur">
        <div className="flex gap-3 pb-[env(safe-area-inset-bottom)]">
          <button
            onClick={handleAddToCart}
            disabled={soldOut}
            className="flex flex-1 items-center justify-center gap-2 rounded-xl border border-primary/60 py-3 text-sm font-semibold text-primary transition-colors hover:bg-primary/10 disabled:cursor-not-allowed disabled:opacity-40"
          >
            <ShoppingBag className="size-4" />
            Add to Cart
          </button>
          <button
            onClick={handleBuyNow}
            disabled={soldOut}
            className="flex flex-1 items-center justify-center gap-2 rounded-xl bg-primary py-3 text-sm font-semibold text-primary-foreground transition-opacity hover:opacity-90 disabled:cursor-not-allowed disabled:opacity-40"
          >
            <Zap className="size-4" />
            {soldOut ? "Sold Out" : "Buy Now"}
          </button>
        </div>
      </div>
    </main>
  )
}
